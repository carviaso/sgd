<html> 
<body>
<div data-role="page">

	<div data-role="header">
		<!-- cabeçalho -->
	</div>

	<div data-role="content">	
		
		<div class="content-menu">
			<!-- menu -->
		</div>

		<div class="content-page">
			<!-- conteúdo da página -->
		</div>
		
	</div>

	<div data-role="footer">
		<!-- rodapé -->
	</div>

</div>
</body>
</html>