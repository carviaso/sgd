<?php
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR.'inc'.DIRECTORY_SEPARATOR.'master.php');

$objPautaC = new PautaC();

?>
<div style="text-align: center;" >
</div>
<table cellpadding="0" cellspacing="0" border="1">
  <tr>
    <th valign='top' colspan='2'>Column 1 Heading</th>
    <th>Column 2 Heading
    	<div style='height: 15px'> &nbsp; </div>
    </th>
  </tr>
  <tr style="margin-bottom: 15px">
    <td style="font-size:10px; ;"></td>
    <td>Row 1: Col 2</td>
  </tr>
</table>
