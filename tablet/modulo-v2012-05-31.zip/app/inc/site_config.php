<?php
define('SITE_TITLE', 'SGD - Sisteme Gestão Docente');
