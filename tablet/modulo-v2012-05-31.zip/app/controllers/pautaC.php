<?php

if(!class_exists("PautaC")) {
	
class PautaC {
	
	function __construct() {}
	
	function __destruct() {}
	
	public function getPautaPorId($id) {
		$objPautaM = new PautaM();
		$objPautaM->setSelect(array(
									'p.id_pauta',
									'p.numero',
									'p.data_insert',
									'p.liberar_pauta')
								);
								
		$objPautaM->setTable('tb_pauta as p');
		$where = "
			WHERE p.id_pauta = '{$id}'";
		$objPautaM->setWhere($where);
		$array = $objPautaM->consulta();
		if($objPautaM->getAffectedRows() > 0)
			$array = array_map("utf8_encode", $array);
		return $array;
	}
	
	public function getPautas($session = false, $condicao = null, $order = 'p.id_pauta DESC') {
		
		/*
		 * Restringir por nível de usuário.
		 * Se for apenas membro deverá mostrar apenas pautas
		 * vinculadas com reuniões
		 */
		$objPautaM = new PautaM();
		
		$objPautaM->setSelect(array(
								'p.id_pauta',
								'p.data_insert',
								'p.numero',
								'p.liberar_pauta',
								'r.local_reuniao',
								'r.data_reuniao')
							);
		
		$objPautaM->setTable('tb_pauta as p');
		$objPautaM->setOrderBy($order);
		
		$where = "
			LEFT JOIN tb_reuniao r ON p.id_pauta=r.id_pauta
			WHERE 1 ";
		
		if($condicao) {
			if(@$condicao['REUNIAO'] != '') {
				$where .= " AND r.id_reuniao IS NULL";
			}
			if(@$condicao['REUNIAO_PAUTA'] != '') {
				$p = "";
				if($condicao['REUNIAO_PAUTA'] != '0') {
					$p = " OR p.id_pauta IN ({$condicao['REUNIAO_PAUTA']})";
				}
				$where .= " AND (r.id_reuniao IS NULL {$p})";
			}
		}
		
		if($session) {
			if(@$_SESSION['CPPD']['FILTRO_PAUTA_NUMERO'] != '') {
				$where .= " AND UPPER(p.numero) LIKE UPPER('%{$_SESSION['CPPD']['FILTRO_PAUTA_NUMERO']}%')";
			}
		}
		
		$objPautaM->setWhere($where);
		$array = $objPautaM->consultaAll();
		
		foreach ($array as &$ar) {
			$ar = array_map("utf8_encode", $ar);
		}

		return $array;
	}
	
	public function editar($idPauta, $numero, $processos, $liberar_pauta) {

		$objPautaM = new PautaM();
		$objPautaM->setWhere("WHERE id_pauta = {$idPauta}");
		
		$arrayPauta = $objPautaM->consulta();
		
		$enviarEmail = false;
		if($arrayPauta['liberar_pauta'] == '0' && $liberar_pauta == '1') {
			$enviarEmail = true;
		}

		$array = array();
		$array['numero'] = $numero;
		$array['liberar_pauta'] = $liberar_pauta;
		$retorno = $objPautaM->update($array);

		if($retorno) {

			$objPautaProcessoM = new PautaProcessoM();
			$objPautaProcessoM->setWhere("WHERE id_pauta = {$idPauta}");
			$retorno = $objPautaProcessoM->delete();
			if($retorno) {

				$objPautoProcessoC = new PautaProcessoC();
				$array = explode(',',$processos);
				foreach ($array as $valor) {
					if($valor != '')
						$objPautoProcessoC->inserir($idPauta, $valor);
				}
				
			}
			if($enviarEmail) {
				/*
				 * Disparar e-mail para os membros
				 */
				$objMembroC = new MembroC();
				$objMembroC->enviarEmailNovaPauta($idPauta);
			}
			
		}

		return $retorno;
	}

	public function inserirPauta($numero, $processos, $liberar_pauta) {

		$objPautaM = new PautaM();

		$obj = new PautaVO();
		$obj->numero = utf8_decode($numero);
		$obj->data_insert = date("Y/m/d h:i:s");
		$obj->liberar_pauta = $liberar_pauta;

		$retorno = $objPautaM->insert($obj);

		if($retorno) {
			/*
			 * Inserir tb_pauta_processo
			 */
			$objPautoProcessoC = new PautaProcessoC();
			$array = explode(',',$processos);
			$idPauta = $objPautaM->getLastId();
			foreach ($array as $valor) {
				if($valor != '')
					$objPautoProcessoC->inserir($idPauta, $valor);
			}
			
			if($liberar_pauta == '1') {
				/*
				 * Disparar e-mail para os membros
				 */
				$objMembroC = new MembroC();
				$objMembroC->enviarEmailNovaPauta($idPauta);
			}
			
		}
		
		return $retorno;

	}
}
}

?>