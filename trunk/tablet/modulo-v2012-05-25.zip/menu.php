<?php
session_start();
?>
<div data-role="page">
	
	<div data-role="header" data-theme="d">
		<h1>Menu</h1>

	</div>

	<div data-role="content" data-theme="c">
		
			<ul data-role="listview" data-theme="c" data-divider-theme="d" data-inset="true">
	
<!--				<li><a href="home.php" data-transition="slide">Home</a></li>-->
				
				<li data-role="list-divider">Minhas Informações</li>
				<li><a href="dados_pessoais.php">Dados pessoais</a></li>
				<li><a href="alterar_senha.php" data-rel="dialog" data-transition="pop">Alterar senha</a></li>
				
				<li data-role="list-divider">Reunião</li>
				<li><a href="#">Nova reuniões</a></li>
				<li><a href="#">Listar reuniões</a></li>
				<li><a href="#">Próxima reunião</a></li>
				
<?php if( in_array($_SESSION['CPPD']['PERFIL'], array('1','2'))) { ?>
				<li data-role="list-divider">Membros da CPPD</li>
				<li><a href="listar_membros.php">Listar Membros</a></li>
				<li><a href="add_membro.php">Adicionar membro</a></li>
<?php } ?>
<?php if( in_array($_SESSION['CPPD']['PERFIL'], array('1','2'))) { ?>
				<li data-role="list-divider">Processo</li>
				<li><a href="novo_processo.php" rel="external">Novo processo</a></li>
				<li><a href="listar_processos.php" rel="external">Listar processos</a></li>
				<li><a href="listar_processos_andamento.php" rel="external">Processos em andamento</a></li>
<?php } ?>
				<li data-role="list-divider">Pauta</li>
				<li><a href="#">Nova pauta</a></li>
				<li><a href="#">Listar pautas</a></li>
	
			</ul>
		
		   
	</div>
</div>