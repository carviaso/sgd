
<li data-role="list-divider">Minhas Informações</li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[1][1])) echo 'a'; ?>"><a href="dados_pessoais.php">Dados pessoais</a></li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[1][2])) echo 'a'; ?>"><a href="alterar_senha.php" data-rel="dialog" data-transition="pop">Alterar senha</a></li>

<li data-role="list-divider">Reunião</li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[2][1])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('nova_reuniao.php', {reloadPage: true});">Nova reuniões</a></li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[2][2])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('listar_reunioes.php', {reloadPage: true});">Listar reuniões</a></li>
<!--<li data-theme="<?php if(in_array($arquivo, $arrayMenu[2][3])) echo 'a'; ?>"><a href="#">Próxima reunião</a></li>-->

<?php if( in_array($_SESSION['CPPD']['PERFIL'], array('1','2'))) { ?>
<li data-role="list-divider">Membros da CPPD</li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[3][1])) echo 'a'; ?>"><a href="listar_membros.php">Listar Membros</a></li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[3][2])) echo 'a'; ?>"><a href="add_membro.php">Adicionar membro</a></li>
<?php } ?>

<li data-role="list-divider">Processo</li>
<?php if( in_array($_SESSION['CPPD']['PERFIL'], array('1','2'))) { ?>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[4][1])) echo 'a'; ?>"><a href="novo_processo.php">Novo processo</a></li>
<?php } ?>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[4][2])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('listar_processos.php', {reloadPage: true});">Listar processos</a></li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[4][3])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('listar_processos_andamento.php', {reloadPage: true});">Processos em andamento</a></li>

<li data-role="list-divider">Pauta</li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[5][1])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('nova_pauta.php', {reloadPage: true});">Nova pauta</a></li>
<li data-theme="<?php if(in_array($arquivo, $arrayMenu[5][2])) echo 'a'; ?>"><a href="#" onclick="$.mobile.changePage('listar_pautas.php', {reloadPage: true});">Listar pautas</a></li>