<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><!-- forçando o IE a usar o seu novo motor de renderização -->
	<title><?php echo SGD_TITULO_PRINCIPAL; ?></title> 
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="./public/jqm/jquery.mobile-corrigido.min.css" />
<!--	<link rel="stylesheet" href="./public/jqm/jquery.mobile-1.1.0.min.css" />-->
	
	<link rel="stylesheet" href="./public/jqm/jqm-docs.css"/>
	<link rel="stylesheet" href="./public/css/estilo.css?<?php echo filemtime('./public/css/estilo.css'); ?>"/>
	
	<script src="./public/jqm/jquery-1.7.min.js"></script>
	
	<script src="./public/jqm/themeswitcher/jquery.mobile.themeswitcher.js"></script>
	<script src="./public/jqm/jqm-docs.js"></script>
	<script src="./public/js/master.js?<?php echo filemtime('./public/js/master.js'); ?>"></script>
	
	<script src="./public/jqm/jquery.mobile-corrigido.min.js"></script>
<!--	<script src="./public/jqm/jquery.mobile-1.1.0.min.js"></script>-->
</head>