<?php

require_once(dirname(__FILE__) . '/../app/library/phpmailer/class.phpmailer.php');

//echo phpinfo();
//die();
$mail = new PHPMailer ();

$mail -> From = "seu_email@gmail.com";
$mail -> FromName = "Seu Nome";
$mail -> AddAddress ("para_alguem@domain.com");
$mail -> Subject = "Email usando SMTP do Google";
$mail -> Body = "<h4>Email enviado do Gmail.</h4>";
$mail -> IsHTML (true);
$mail -> IsSMTP();
$mail -> Host = 'ssl://smtp.gmail.com';
$mail -> Port = 465;
$mail -> SMTPAuth = true;
$mail -> Username = 'seu_email@gmail.com';
$mail -> Password = 'sua_senha';

if(!$mail->Send()) {
                echo 'Erro:'.$mail->ErrorInfo;
} else {
                echo 'Email enviado!';
}

