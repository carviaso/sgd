<?php

if(!class_exists("VotacaoC")) {
	
class VotacaoC {
	
	function __construct() {}
	
	function __destruct() {}
	
}
}

?>