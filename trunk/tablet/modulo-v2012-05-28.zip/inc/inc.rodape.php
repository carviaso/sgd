<div data-role="footer" class="footer-docs" data-theme="c" data-fullscreen="true" style="height: 45px">
		<p>&copy; 2012 - UFSC - Universidade Federal de Santa Catarina. CPPD/SGD.</p>
</div>