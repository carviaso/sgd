<div id="alterar-senha" data-role="page">
	
	<div data-role="header" data-theme="d">
		<h1>Alterar senha</h1>

	</div>

	<div data-role="content" data-theme="c">
		<div data-role="fieldcontain">
	        <label for="senha-atual">Senha atual:</label>
	        <input type="password" name="name" id="senha-atual" value=""  />
		</div>
		<div data-role="fieldcontain">
	        <label for="nova-senha">Nova senha:</label>
	        <input type="password" name="name" id="nova-senha" value=""  />
		</div>
		<div data-role="fieldcontain">
	        <label for="confirmar-senha">Confirmar senha:</label>
	        <input type="password" name="name" id="confirmar-senha" value=""  />
		</div>
		<a href="#" data-inline="true" data-role="button" data-rel="back" data-theme="e">Cancelar</a>       
		<input id="bSalvarNovaSenha" type="button" data-role="button" data-theme="c" value="Salvar" data-inline="true" />    
	</div>
</div>