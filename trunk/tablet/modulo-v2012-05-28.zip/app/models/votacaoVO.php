<?php

if(!class_exists("VotacaoVO")) {
	
class VotacaoVO extends EntidadeModelo {
	
	function __construct($complete = false) {
		if($complete) {
			$this->id_votacao = '';
			$this->id_membro = '';
			$this->id_processo = '';
			$this->voto = '';
			$this->data_insert = '';
		}
	}

}
}

?>