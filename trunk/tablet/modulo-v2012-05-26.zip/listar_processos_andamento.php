<?php
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR.'inc'.DIRECTORY_SEPARATOR.'master.php');

$objProcessoC = new ProcessoC();
$condicao = array();
$condicao['STATUS'] = '3,4,5,7,8';
$array = $objProcessoC->getProcessos(false, $condicao);

//echo '<pre>';
//print_r($array);
//die();
?>
<html class="ui-mobile-rendering">
<?php
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR.'inc'.DIRECTORY_SEPARATOR.'inc.head.php');
?>
<body>
<div id="listar-membros-andamento" data-role="page" class="type-interior">

	<div data-role="header" data-position="fixed" data-theme="a">
		<h1><?php echo SGD_TITULO_CABECALHO; ?></h1>
		<a href="index.php?logout=true" data-transition="fade" data-theme="e">Sair</a>
		<a href="menu.php" id="btn-menu-header" data-rel="dialog" data-transition="fade" data-theme="e">Menu</a>
	</div><!-- /header -->

	<div data-role="content">	
		
		<div class="content-secondary">
			<div data-role="collapsible" data-collapsed="true" data-theme="b" data-content-theme="d">

					<ul data-role="listview" data-theme="c" data-dividertheme="d">

						<?php include_once("./inc/menu_lateral.php"); ?>

					</ul>
			</div>
		</div>

		<div class="ui-grid-a">
			<div style="margin-left: 2px;"><div class="ui-bar ui-bar-c" data-role="header" style="padding: 1px">
				<h1>Listar Processos em Andamento</h1>
			</div></div>
		</div>
		<div class="content-primary">
			<?php
			if(count($array) > 0) { ?>
				<ul data-role="listview" data-inset="true">
				<?php foreach ($array as $processo) { ?>
				<li data-icon="false" id="li-processo-<?php echo "{$processo['id_processo']}"; ?>">
					<a href="#" class="lista-processo-unique" id="linha-processo-<?php echo "{$processo['id_processo']}"; ?>" data-processoid="<?php echo "{$processo['id_processo']}"; ?>"
						 data-processonumero="<?php echo "{$processo['numero']}"; ?>" data-transition="slide" data-theme="a" data-prefetch>
						<h3 style="white-space:normal;">Processo: <?php echo "{$processo['numero']}"; ?>, <?php echo "{$processo['nome_requerente']} ({$processo['siglaDepartamento']}/{$processo['siglaCentro']})"; ?></h3>
						<p><strong>Assunto: <?php echo "{$processo['assunto']}"; ?></strong></p>
						<p><strong>Status: <?php echo "{$processo['nome_status']}"; ?></strong></p>
						<p>Relator: <?php echo "{$processo['nome_relator']}"; ?></p>
						<div class="btn-listview-button">
							<?php if($processo['parecer'] != '') { ?>
								<button onclick="visualizarParecerProcesso('parecer-<?php echo "{$processo['id_processo']}"; ?>')" id="btn-parecer-<?php echo "{$processo['id_processo']}"; ?>" type="submit" data-theme="e" data-icon="arrow-d" data-mini="true" data-inline="true">Parecer</button>
							<?php } ?>
							<button onclick="processoEditForm('<?php echo "{$processo['id_processo']}"; ?>','2')" type="submit" data-theme="c" data-icon="gear" data-mini="true" data-inline="true">Editar</button>
	
							<button onclick="processoExcluir('<?php echo "{$processo['id_processo']}"; ?>')" type="submit" data-theme="c" data-icon="delete" data-mini="true" data-inline="true">Excluir</button>
						</div>
						<?php if($processo['parecer'] != '') { ?>
						<div id="parecer-<?php echo "{$processo['id_processo']}"; ?>" style="display: none; margin: 10px 0;clear: both;">
							<p><?php echo nl2br($processo['parecer']); ?></p>
						</div>
						<?php } ?>
					</a>
					
				</li>
				<?php } ?>
			</ul>
			<?php } else {
				echo "Nenhum processo em andamento.";
			}?>
		</div>
		
	</div><!-- /content -->

	<?php require_once(dirname(__FILE__) . '/inc/inc.rodape.php'); ?>

</div>

</body>
</html>