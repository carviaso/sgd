<?php

if(!class_exists("ReuniaoC")) {
	
class ReuniaoC {
	
	function __construct() {}
	
	function __destruct() {}
	
	public function editar($id_reuniao, $id_pauta, $id_status, $local, $dia, $mes, $ano, $hora, $minuto, $motivo_cancelamento) {
		
		$data  = mktime($hora, $minuto, 0, $mes,  $dia,  $ano);
		
		$objReuniaoM = new ReuniaoM();
		$array = array();
		$array['id_pauta'] = $id_pauta;
		$array['local_reuniao'] = utf8_decode($local);
		$array['data_reuniao'] = date("Y/m/d H:i:s", $data);
		$array['status_reuniao'] = $id_status;
		$array['motivo_cancelamento'] = ($id_status == '2')?utf8_decode($motivo_cancelamento):'';
		
		$objReuniaoM->setWhere("WHERE id_reuniao = {$id_reuniao}");
		$retorno = $objReuniaoM->update($array);
		
		return $retorno;
		
	}
	
	public function getReuniaoPorId($id) {
		
		$objReuniaoM = new ReuniaoM();
		$objReuniaoM->setSelect(array(
									'r.id_reuniao',
									'p.id_pauta',
									'p.numero AS numero_pauta',
									"if(status_reuniao=0,'A ser realizada', if(status_reuniao=1, 'Realizada',if(status_reuniao=2, 'Cancelada','Transferida'))) as nome_status_reuniao ",
									'r.data_insert',
									"date_format(r.data_reuniao,'%d/%m/%Y %H:%i') as data_reuniao",
									"date_format(r.data_reuniao,'%d') as data_reuniao_dia",
									"date_format(r.data_reuniao,'%m') as data_reuniao_mes",
									"date_format(r.data_reuniao,'%Y') as data_reuniao_ano",
									"date_format(r.data_reuniao,'%H') as data_reuniao_hora",
									"date_format(r.data_reuniao,'%i') as data_reuniao_minuto",
									'r.local_reuniao',
									'r.status_reuniao',
									'r.ata',
									'r.liberar_ata',
									'r.motivo_cancelamento',)
								);

								
		$objReuniaoM->setTable('tb_reuniao as r');
		$where = "
			LEFT JOIN tb_pauta p ON p.id_pauta=r.id_pauta
			WHERE r.id_reuniao = '{$id}'";
		$objReuniaoM->setWhere($where);
		$array = $objReuniaoM->consulta();
		$array = array_map("utf8_encode", $array);
		return $array;
	}
	
	public function inserir($id_pauta, $local, $dia, $mes, $ano, $hora, $minuto) {
		
		$objReuniaoM = new ReuniaoM();
		
		$data  = mktime($hora, $minuto, 0, $mes,  $dia,  $ano);
		
//		$status = ($id_pauta == '' || $id_pauta == '0')?'0':'1';
		$status = '0';

		$obj = new ReuniaoVO();
		$obj->id_pauta = $id_pauta;
		$obj->data_insert = date("Y/m/d H:i:s");
		$obj->data_reuniao = date("Y/m/d H:i:s", $data);
		$obj->local_reuniao = utf8_decode($local);
		$obj->status_reuniao = $status;

		$retorno = $objReuniaoM->insert($obj);

		return $retorno;
		
		return true;
	} 
	
	public function getReunioes($session = false, $order = 'r.data_reuniao asc') {
		
		$objReuniaoM = new ReuniaoM();
		
		$objReuniaoM->setSelect(array(
								'r.id_reuniao',
								'p.id_pauta',
								'p.numero AS numero_pauta',
								"if(status_reuniao=0,'A ser realizada', if(status_reuniao=1, 'Realizada',if(status_reuniao=2, 'Cancelada','Transferida'))) as nome_status_reuniao ",
								'r.data_insert',
								"date_format(r.data_reuniao,'%d/%m/%Y %H:%i') as data_reuniao",
								'r.local_reuniao',
								'r.status_reuniao',
								'r.ata',
								'r.liberar_ata')
							);
		
		$objReuniaoM->setTable('tb_reuniao as r');
		$objReuniaoM->setOrderBy($order);
		
		$where = "
			LEFT JOIN tb_pauta p ON p.id_pauta=r.id_pauta
			WHERE 1 ";
		
		if($session) {
			if(@$_SESSION['CPPD']['FILTRO_REUNIAO_ID_PAUTA'] != '') {
				$where .= " AND r.id_pauta IN ({$_SESSION['CPPD']['FILTRO_REUNIAO_ID_PAUTA']})";
			}
			if(@$_SESSION['CPPD']['FILTRO_REUNIAO_ID_STATUS'] != '') {
				$where .= " AND r.status_reuniao IN ({$_SESSION['CPPD']['FILTRO_REUNIAO_ID_STATUS']})";
			}
			if(@$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_INICIO'] != '' && @$_SESSION['CPPD']['FILTRO_REUNIAO_MES_INICIO'] != '') {
				$where .= " AND YEAR(r.data_reuniao) >= '{$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_INICIO']}'";
				$where .= " AND MONTH(r.data_reuniao) >= '{$_SESSION['CPPD']['FILTRO_REUNIAO_MES_INICIO']}'";
				if(@$_SESSION['CPPD']['FILTRO_REUNIAO_DIA_INICIO'] != '') {
					$where .= " AND DAY(r.data_reuniao) >= '{$_SESSION['CPPD']['FILTRO_REUNIAO_DIA_INICIO']}'";
				}
			} elseif(@$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_INICIO'] != '') {
				$where .= " AND YEAR(r.data_reuniao) >= '{$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_INICIO']}'";
			}
			if(@$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_FINAL'] != '' && @$_SESSION['CPPD']['FILTRO_REUNIAO_MES_FINAL'] != '') {
				$where .= " AND YEAR(r.data_reuniao) <= '{$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_FINAL']}'";
				$where .= " AND MONTH(r.data_reuniao) >= '{$_SESSION['CPPD']['FILTRO_REUNIAO_MES_FINAL']}'";
				if(@$_SESSION['CPPD']['FILTRO_REUNIAO_DIA_FINAL'] != '') {
					$where .= " AND DAY(r.data_reuniao) <= '{$_SESSION['CPPD']['FILTRO_REUNIAO_DIA_FINAL']}'";
				}
			} elseif(@$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_FINAL'] != '') {
				$where .= " AND YEAR(r.data_reuniao) <= '{$_SESSION['CPPD']['FILTRO_REUNIAO_ANO_FINAL']}'";
			}
		}
		
		$objReuniaoM->setWhere($where);
		$array = $objReuniaoM->consultaAll();
		
		foreach ($array as &$ar) {
			$ar = array_map("utf8_encode", $ar);
		}

		return $array;
		
	}
	
}
}

?>