<?php

if(!class_exists("ProcessoC")) {
	
class ProcessoC {
	
	function __construct() {}
	
	function __destruct() {}
	
	public function getProcessoPorId($id) {
		$objProcessoM = new ProcessoM();
		$objProcessoM->setSelect(array(
									'p.id_processo',
									'p.numero',
									'p.id_assunto_processo',
									'ap.nome as assunto',
									'p.id_professor_relator',
									'mprof.nome as nome_relator',
									'p.id_professor_requerente',
									'preq.nome as nome_requerente',
									'd.sigla as siglaDepartamento',
									'cen.sigla as siglaCentro',
									'p.id_status_processo',
									'sp.nome as nome_status',
									'p.parecer')
								);

								
		$objProcessoM->setTable('tb_processo as p');
		$where = "
			INNER JOIN tb_assunto_processo AS ap ON p.id_assunto_processo=ap.id_assunto_processo
			INNER JOIN professor AS preq ON p.id_professor_requerente=preq.id_professor
			INNER JOIN tb_membro AS m ON p.id_professor_relator=m.id_membro
			INNER JOIN professor AS mprof ON m.id_professor=mprof.id_professor
			INNER JOIN tb_status_processo AS sp ON p.id_status_processo=sp.id_status_processo
			LEFT JOIN departamento AS d on preq.id_departamento = d.id_departamento
			LEFT JOIN centro AS cen on d.id_centro = cen.id_centro
			WHERE p.id_processo = '{$id}'";
		$objProcessoM->setWhere($where);
		$array = $objProcessoM->consulta();
		$array = array_map("utf8_encode", $array);
		return $array;
	}
	
	public function atualizarProcessoSimplificado($id_processo, $id_status, $id_requerente, $id_relator, $parecer) {
	
		$objProcessoM = new ProcessoM();

		$array = array();
		if($id_relator!= '')
			$array['id_professor_relator'] = $id_relator;

		if($id_requerente != '')
			$array['id_professor_requerente'] = $id_requerente;

		if($id_status != '')
			$array['id_status_processo'] = $id_status;

		$array['parecer'] = utf8_decode($parecer);
		
		$objProcessoM->setWhere("WHERE id_processo = '{$id_processo}'");

		$retorno = $objProcessoM->update($array);		
		return $retorno;
		
	}
	
	public function atualizarProcesso($id_processo, $numero, $id_status, $id_assunto, $id_requerente, $id_relator, $parecer) {
		
		$objProcessoM = new ProcessoM();

		$array = array();
		$array['numero'] = utf8_decode($numero);
		$array['id_professor_relator'] = $id_relator;
		$array['id_professor_requerente'] = $id_requerente;
		$array['id_assunto_processo'] = $id_assunto;
		$array['id_status_processo'] = $id_status;
		$array['parecer'] = utf8_decode($parecer);
		
		$objProcessoM->setWhere("WHERE id_processo = '{$id_processo}'");

		$retorno = $objProcessoM->update($array);		
		return $retorno;
		
	}
	
	public function inserirProcesso($numero, $id_status, $id_assunto, $id_requerente, $id_relator, $parecer) {

		$objProcessoM = new ProcessoM();

		$obj = new ProcessoVO();
		$obj->numero = utf8_decode($numero);
		$obj->id_professor_relator = $id_relator;
		$obj->id_professor_requerente = $id_requerente;
		$obj->id_assunto_processo = $id_assunto;
		$obj->id_status_processo = $id_status;
		$obj->parecer = utf8_decode($parecer);
		$obj->data_insert = date("Y/m/d h:i:s");
		$obj->cadastro_id_professor = $_SESSION['CPPD']['ID_PROFESSOR'];

		$retorno = $objProcessoM->insert($obj);		
		return $retorno;

	}
	
	public function getProcessos($session = false, $condicao = array()){
		$objProcessoM = new ProcessoM();
		$objProcessoM->setSelect(array(
									'p.id_processo',
									'p.numero',
									'p.id_assunto_processo',
									'ap.nome as assunto',
									'p.id_professor_relator',
									'mprof.nome as nome_relator',
									'p.id_professor_requerente',
									'preq.nome as nome_requerente',
									'd.sigla as siglaDepartamento',
									'cen.sigla as siglaCentro',
									'p.id_status_processo',
									'sp.nome as nome_status',
									'p.parecer')
								);

		$objProcessoM->setTable('tb_processo as p');
		$where = "
			INNER JOIN tb_assunto_processo AS ap ON p.id_assunto_processo=ap.id_assunto_processo
			INNER JOIN professor AS preq ON p.id_professor_requerente=preq.id_professor
			INNER JOIN tb_membro AS m ON p.id_professor_relator=m.id_membro
			INNER JOIN professor AS mprof ON m.id_professor=mprof.id_professor
			INNER JOIN tb_status_processo AS sp ON p.id_status_processo=sp.id_status_processo
			LEFT JOIN departamento AS d on preq.id_departamento = d.id_departamento
			LEFT JOIN centro AS cen on d.id_centro = cen.id_centro
			";
		
		/*
		 * Validar sessao
		 */
		$con = '';
		if(count($condicao) > 0) {
			if(@$condicao['STATUS']) {
				$con .= " AND p.id_status_processo IN ({$condicao['STATUS']})";
			}
			if(@$condicao['ID_PAUTA']) {
				$where .= "
					INNER JOIN tb_pauta_processo AS pautp ON p.id_processo=pautp.id_processo
					INNER JOIN tb_pauta AS paut ON pautp.id_pauta=paut.id_pauta";
				$con .= " AND paut.id_pauta IN ({$condicao['ID_PAUTA']})";
			}
		}
		if($session) {
			if(@$_SESSION['CPPD']['FILTRO_PROCESSO_NUMERO'] != '') {
				$con .= " AND UPPER(p.numero) LIKE UPPER('%{$_SESSION['CPPD']['FILTRO_PROCESSO_NUMERO']}%')";
			}
			if(@$_SESSION['CPPD']['FILTRO_PROCESSO_STATUS'] != '' && @$_SESSION['CPPD']['FILTRO_PROCESSO_STATUS'] != '0') {
				$con .= " AND p.id_status_processo IN ({$_SESSION['CPPD']['FILTRO_PROCESSO_STATUS']})";
			}
			if(@$_SESSION['CPPD']['FILTRO_PROCESSO_ASSUNTO'] != '' && @$_SESSION['CPPD']['FILTRO_PROCESSO_ASSUNTO'] != '0') {
				$con .= " AND p.id_assunto_processo IN ({$_SESSION['CPPD']['FILTRO_PROCESSO_ASSUNTO']})";
			}
			if(@$_SESSION['CPPD']['FILTRO_PROCESSO_ID_REQ'] != '') {
				$con .= " AND preq.id_professor IN ({$_SESSION['CPPD']['FILTRO_PROCESSO_ID_REQ']})";
			}
			if(@$_SESSION['CPPD']['FILTRO_PROCESSO_ID_REL'] != '') {
				$con .= " AND m.id_membro IN ({$_SESSION['CPPD']['FILTRO_PROCESSO_ID_REL']})";
			}
		}
		
		$where .= " WHERE 1 {$con}";
		
		$objProcessoM->setWhere($where);
		$objProcessoM->setOrderBy("p.id_processo DESC");
		$array = $objProcessoM->consultaAll();
	
		foreach ($array as &$ar) {
			$ar = array_map("utf8_encode", $ar);
		}

		return $array;
	}

}
}

?>