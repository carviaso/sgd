<?php


session_start();
echo '<pre>';
print_r($_SESSION);

die();

$ar = array();
$ar[] = 'XML - Extensible Markup Language';
$ar[] = 'W3C - World Wide Web Consortium';
$ar[] = 'SQL - Structured Query Language';
$ar[] = 'UI - User Interface';
$ar[] = 'SGD - Sistema de Gestão de Docentes';
$ar[] = 'SGBD - Sistema de Gerenciamento de Banco de Dados';
$ar[] = 'CSS - Cascading Style Sheets';
$ar[] = 'HTML - Hypertext Markup Language';
$ar[] = 'DOM - Document Object Model';
$ar[] = 'AJAX - Asynchronous Javascript And XML';
$ar[] = 'WHATWG - The Web Hypertext Application Technology Working Group';
$ar[] = 'WEB - World Wide Web';
$ar[] = 'IE - Internet Explorer';
$ar[] = 'FTP - File Transfer Protocol';
$ar[] = 'JDBC - Java Database Connectivity';
$ar[] = 'PHP - Hypertext Preprocessor';
$ar[] = 'PDT - PHP Development Tools';
$ar[] = 'JQM - JQuery Mobile';
$ar[] = 'RGB - abreviatura de Red, Green e Blue';
$ar[] = 'JS - JavaScript';
$ar[] = 'API - Application Programming Interface';

sort($ar);

foreach ($ar as $key => $value) {
	echo $value.'<br>';
}